package application;

import application.model.GameModel;
import application.model.GameModelListener;
import javafx.event.EventHandler;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.HBox;

public class DeckView extends HBox implements GameModelListener {

    private static final String BUTTON_STYLE_NORMAL = "-fx-background-color: transparent; -fx-padding: 5,5,5,5;";
    private static final String BUTTON_STYLE_PRESSED = "-fx-background-color: transparent; -fx-padding: 6,4,4,6;";

    public DeckView() {
        GameModel.getInstance().reset();

        ImageView cardImageView = new ImageView(CardImages.getBack());
        cardImageView.setStyle(BUTTON_STYLE_NORMAL);

        // Event handler for mouse click to draw a card from the deck
        cardImageView.setOnMouseClicked(event -> {
            GameModel.getInstance().getDeckMove().move();
        });

        cardImageView.setOnMousePressed(event -> {
            cardImageView.setStyle(BUTTON_STYLE_PRESSED);
            // Start dragging when the mouse is pressed
            cardImageView.startFullDrag();
        });

        cardImageView.setOnMouseReleased(event -> {
            cardImageView.setStyle(BUTTON_STYLE_NORMAL);
        });

        cardImageView.setOnDragDetected(event -> {
            /* drag was detected, start a drag-and-drop gesture */
            Dragboard db = cardImageView.startDragAndDrop(TransferMode.MOVE);
            /* Put a string on a dragboard */
            ClipboardContent content = new ClipboardContent();
            content.putImage(CardImages.getBack()); // Put the image on the dragboard
            db.setContent(content);
            event.consume();
        });

        getChildren().add(cardImageView);
        GameModel.getInstance().addListener(this);
    }

    @Override
    public void gameStateChanged() {
        // TODO Auto-generated method stub
    }

    public void reset() {
        // Clears the children nodes of the deck view
        getChildren().clear();
    }
}
