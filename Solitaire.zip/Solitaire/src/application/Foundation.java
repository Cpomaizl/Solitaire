package application;

import application.card.Card;
import application.card.Rank;
import application.card.Suit;

public class Foundation {
	private Suit suit;
	private int expectedRank = 1;
	private Card[] cards;

	public Foundation(Suit suit) {
		this.suit = suit;
		this.cards = new Card[13];
	}

	public boolean canAccept(Card card) {
		// Can foundation accept an Ace of the correct suit
		if (card.getRank() == Rank.ACE) {
			return card.getSuit() == this.suit;
		} else if (expectedRank > 0 && expectedRank <= 13) {

			return card.getSuit() == this.suit && card.getRank().ordinal() == expectedRank - 1;
		}
		return false;
	}

	public boolean addCard(Card card) {
		if (expectedRank > 0 && expectedRank <= 13) {

			if (expectedRank == card.getRank().ordinal() + 1) {

				if (cards[expectedRank - 1] == null) {
					cards[expectedRank - 1] = card;
					expectedRank++;
					return true;
				} else {

					return false;
				}
			} else if (expectedRank == 1 && card.getRank() == Rank.ACE) {

				if (cards[0] == null) {
					cards[0] = card;
					expectedRank++;
					return true;
				} else {

					return false;
				}
			}
		}
		return false;
	}

	public boolean containsCard(Card card) {
		for (Card foundationCard : cards) {
			if (foundationCard != null && foundationCard.getRank() == card.getRank()
					&& foundationCard.getSuit() == card.getSuit()) {
				return true;
			}
		}
		return false;
	}
}
