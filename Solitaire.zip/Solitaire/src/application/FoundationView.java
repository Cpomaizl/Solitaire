package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import application.card.Card;
import application.card.Rank;
import application.card.Suit;

public class FoundationView extends GridPane implements WasteView.WasteViewListener {
    private static final int NUM_SUITS = 4;
    private static final int NUM_RANKS = 13;
    private ImageView[][] imageViews = new ImageView[NUM_SUITS][NUM_RANKS];
    private Rank[] currentRanks = new Rank[NUM_SUITS];

    public FoundationView() {
        setHgap(5);
        setVgap(5);

        for (int i = 0; i < NUM_SUITS; i++) {
            for (int j = 0; j < NUM_RANKS; j++) {
                imageViews[i][j] = new ImageView();
                add(imageViews[i][j], i, j);
            }
        }
    }

    @Override
    public void onCardMovedToFoundation(Image cardImage, Card card) {
        Suit cardSuit = card.getSuit();
        Rank cardRank = card.getRank();
        int suitIndex = getSuitIndex(cardSuit);

        if (suitIndex >= 0) {
            if (currentRanks[suitIndex] == null) {
                if (cardRank == Rank.ACE) {
                    addCardToFoundation(cardImage, suitIndex, cardRank.ordinal());
                    currentRanks[suitIndex] = cardRank;
                }
            } else {
                Rank currentRank = currentRanks[suitIndex];
                if (cardRank.ordinal() == currentRank.ordinal() + 1) {
                    addCardToFoundation(cardImage, suitIndex, cardRank.ordinal());
                    currentRanks[suitIndex] = cardRank;
                }
            }
        }
    }

    private int getSuitIndex(Suit suit) {
        switch (suit) {
            case CLUBS:
                return 0;
            case DIAMONDS:
                return 1;
            case SPADES:
                return 2;
            case HEARTS:
                return 3;
            default:
                return -1;
        }
    }

    private void addCardToFoundation(Image cardImage, int suitIndex, int rankIndex) {
        imageViews[suitIndex][rankIndex].setImage(cardImage);
    }
}
