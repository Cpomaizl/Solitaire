package application; 

import java.util.List;
import application.card.Card;
import application.model.GameModel;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Main extends Application {

    private static final int WIDTH = 1000;
    private static final int HEIGHT = 500;
    private static final String TITLE = "Solitaire";
    private static final String VERSION = "Project Group 14";
    private static final int STOCKPILE_ROW = 1; 
    private static final int STOCKPILE_COL_START = 1; 
    private static final int STOCKPILE_COL_COUNT = 7; 
    private static final double CARD_WIDTH = 100; 
    private static final double CARD_HEIGHT = 160; 
    private DeckView deckView = new DeckView();
    private WasteView wasteView = new WasteView();
    private FoundationView[] foundationViews;
    private Button newGameButton; 
    private Label scoreLabel;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        SplashScreen splashScreen = new SplashScreen();
        splashScreen.show(primaryStage, () -> {
            primaryStage.setTitle(TITLE + " " + VERSION);

            BorderPane root = new BorderPane();

            // Solitaire background image
            Image backgroundImage = new Image("images/solitaire background.png");
            root.setStyle(
                    "-fx-background-image: url('" + backgroundImage.getUrl() + "'); " + "-fx-background-size: cover;");

            GridPane centerPane = new GridPane();
            centerPane.setPadding(new Insets(10)); 

            
            centerPane.add(deckView, 0, 0);
            centerPane.add(wasteView, 1, 0);

            
            int emptyCellsBeforeStockpile = STOCKPILE_COL_START - 0;

           
            for (int i = 0; i < emptyCellsBeforeStockpile; i++) {
                centerPane.add(new GridPane(), i, STOCKPILE_ROW);
            }

       
            for (int i = 0; i < STOCKPILE_COL_COUNT; i++) {
                StockpileView stockpileView = new StockpileView();
                stockpileView.setPrefSize(CARD_WIDTH, CARD_HEIGHT); 
                centerPane.add(stockpileView, STOCKPILE_COL_START + i, STOCKPILE_ROW);
            }

            // Add foundation views
            foundationViews = new FoundationView[4];
            int startingColumn = 2;
            for (int i = 0; i < 4; i++) {
                foundationViews[i] = new FoundationView();
                centerPane.add(foundationViews[i], startingColumn + i, 0);
            }

            // Set the WasteViewListener for each FoundationView
            for (FoundationView foundationView : foundationViews) {
                wasteView.setWasteViewListener(foundationView);
            }

            // Add padding to centerPane 
            centerPane.setPadding(new Insets(1, 1, 1, 1)); 

         // Deal tableau cards
            List<Card>[] tableau = GameModel.getInstance().getTableau();
            for (int i = 0; i < tableau.length; i++) {
                List<Card> column = tableau[i];
                StackPane stackPane = new StackPane(); 
                double yOffset = 0;
                for (int j = 0; j < column.size(); j++) {
                    Card card = column.get(j);
                    ImageView imageView;
                    if (j < i) {
                        // Deal face-down cards for the first few cards in each column
                        imageView = new ImageView(CardImages.getBack());
                    } else {
                        // Deal face-up cards for the rest of the cards in each column
                        Image cardImage = CardImages.getImage(card);
                        imageView = new ImageView(cardImage);
                        // Add event handler to face-up card
                        imageView.setOnMouseClicked(event -> {
                            if (isValidMove(card)) {
                                // Move the card to the foundation
                                onCardMovedToFoundation(cardImage, card);
                            }
                        });
                    }

                    imageView.setFitHeight(150); 
                    imageView.setTranslateY(yOffset); 
                    stackPane.getChildren().add(imageView); 
                    yOffset += 15; 
                }

                centerPane.add(stackPane, STOCKPILE_COL_START + i, STOCKPILE_ROW); 
            }


            // Create a New Game button
            newGameButton = new Button("Start New Game");
            newGameButton.setOnAction(event -> {
                try {
                    resetGame();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            // Create a button to display game rules
            Button rulesButton = new Button("Game Rules");
            rulesButton.setOnAction(event -> showGameRulesPopup());

            // Create an exit button
            Button exitButton = new Button("Exit");
            exitButton.setOnAction(event -> primaryStage.close());

            // Add buttons to the bottom bar
            HBox buttonBox = new HBox(10);
            buttonBox.getChildren().addAll(newGameButton, rulesButton, exitButton);
            buttonBox.setPadding(new Insets(10));

            // Create the score label
            scoreLabel = new Label("Score: 0");
            scoreLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: white;");

            // Add score label to the bottom bar
            buttonBox.getChildren().add(scoreLabel);

            root.setCenter(centerPane);
            root.setBottom(buttonBox);

            // Add border to the centerPane
            centerPane.setStyle("-fx-border-color: black; -fx-border-width: 0 0 1 0;");

            primaryStage.setScene(new Scene(root, WIDTH, HEIGHT));
            primaryStage.show();

         
            deckView.setOnMouseClicked(event -> {
                
            });
        });

      
        GameModel gameModel = GameModel.getInstance();
        gameModel.addListener(() -> updateScore(gameModel.getScore()));
    }

    private boolean isValidMove(Card card) {
        // TODO: Implement the logic to check if moving the card to the foundation is a valid move
        return false;
    }

    private void onCardMovedToFoundation(Image cardImage, Card card) {
        // TODO: Implement the logic for moving the card to the foundation
    }

    private void resetGame() throws Exception {
        // Close the current window
        Stage stage = (Stage) newGameButton.getScene().getWindow();
        stage.close();

        // Open a new window
        Stage newStage = new Stage();
        start(newStage);
    }

    private void updateScore(int score) {
        scoreLabel.setText("Score: " + score);
    }

    // Method to display game rules in a popup
    private void showGameRulesPopup() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Game Rules");

        Label titleLabel = new Label("Game Rules");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Label rulesLabel = new Label(
                "Solitaire, a solitary card game, tasks players with organizing a shuffled deck into four foundation piles, each representing a suit and progressing from Ace to King. Setup involves dealing seven piles of cards, incrementally increasing in size, with the top card of each pile revealed. Gameplay centers on maneuvering cards between piles, adhering to rules such as stacking cards in descending order and alternating colors. A key objective is to reveal face-down cards by strategically moving those on top, utilizing empty spaces, and drawing from the deck as needed. Victory is achieved when all cards are successfully transferred to the foundation piles in ascending order and by suit.");
        rulesLabel.setWrapText(true);

        VBox popupLayout = new VBox(10);
        popupLayout.getChildren().addAll(titleLabel, rulesLabel);
        popupLayout.setAlignment(javafx.geometry.Pos.CENTER);
        popupLayout.setPadding(new Insets(10));

        Scene popupScene = new Scene(popupLayout, 500, 300);
        popupStage.setScene(popupScene);
        popupStage.showAndWait();
    }
}
