package application;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

public class SplashScreen extends Application {

    private static final int SPLASH_DURATION_SECONDS = 3; // Duration of splash screen in seconds

    public void show(Stage primaryStage, Runnable onFinish) {
        primaryStage.setTitle("Solitaire");

        // Create a label for the splash screen
        Label splashLabel = new Label("Welcome to Solitaire!");
        splashLabel.setStyle("-fx-font-size: 24px;");

        // StackPane to center the label
        StackPane splashRoot = new StackPane(splashLabel);
        splashRoot.setAlignment(Pos.CENTER);
        
        // Set green background color
        splashRoot.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));

        // Create the splash scene
        Scene splashScene = new Scene(splashRoot,1000, 500);

        // Show the splash screen
        primaryStage.setScene(splashScene);
        primaryStage.show();

        // Set up a timeline to switch to the main scene after the splash duration
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(SPLASH_DURATION_SECONDS), event -> {
            // Call the onFinish runnable when the splash duration is over
            onFinish.run();
        }));
        timeline.play();
    }

    @Override
    public void start(Stage primaryStage) {
        // This method will not be used, as the show method is used instead
    }

    public static void main(String[] args) {
        launch(args);
    }
}
