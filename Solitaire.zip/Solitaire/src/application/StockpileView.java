package application;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.HBox;

public class StockpileView extends HBox {

    private static final double CARD_WIDTH = 100;
    private static final double CARD_HEIGHT = 160;
    

    public StockpileView() {
        setSpacing(5); // Spacing between cards

        // Enable dropping cards onto the stockpile
        setOnDragOver(this::handleDragOver);
        setOnDragDropped(this::handleDragDropped);
    }

    private void handleDragOver(DragEvent event) {
        if (event.getGestureSource() instanceof ImageView) {
            event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
        }
        event.consume();
    }

    private void handleDragDropped(DragEvent event) {
        if (event.getGestureSource() instanceof ImageView) {
            ImageView source = (ImageView) event.getGestureSource();
            Dragboard db = event.getDragboard();
            boolean success = false;
            if (db.hasImage()) {
                ImageView cardImageView = new ImageView(db.getImage());
                cardImageView.setFitWidth(CARD_WIDTH);
                cardImageView.setFitHeight(CARD_HEIGHT);
                getChildren().add(cardImageView);
                success = true;
            }
            event.setDropCompleted(success);
        }
        event.consume();
    }

    public void addCard(Image cardImage) {
        ImageView cardImageView = new ImageView(cardImage);
        cardImageView.setFitWidth(CARD_WIDTH);
        cardImageView.setFitHeight(CARD_HEIGHT);

        // Add event handlers for mouse press, drag, and release
        cardImageView.setOnMousePressed(event -> handleMousePressed(cardImageView, event));
        cardImageView.setOnMouseDragged(event -> handleMouseDragged(cardImageView, event));
        cardImageView.setOnMouseReleased(event -> handleMouseReleased(cardImageView));

        getChildren().add(cardImageView);
    }

    private void handleMousePressed(ImageView cardImageView, javafx.scene.input.MouseEvent event) {
        // Record the initial mouse position and card position
        cardImageView.toFront(); // Bring the card to the front
        cardImageView.setUserData(new double[]{event.getSceneX(), event.getSceneY(), cardImageView.getLayoutX(), cardImageView.getLayoutY()});
    }

    private void handleMouseDragged(ImageView cardImageView, javafx.scene.input.MouseEvent event) {
        // Calculate the new card position based on mouse movement
        double[] data = (double[]) cardImageView.getUserData();
        double deltaX = event.getSceneX() - data[0];
        double deltaY = event.getSceneY() - data[1];

        // Constrain the movement within the stockpile bounds
        double newX = data[2] + deltaX;
        double newY = data[3] + deltaY;

        cardImageView.setLayoutX(newX);
        cardImageView.setLayoutY(newY);
    }

    private void handleMouseReleased(ImageView cardImageView) {
        // Reset the mouse position
        cardImageView.setUserData(null);
    }
}
