package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

import java.util.Collections;

import application.card.Card;
import application.model.GameModel;
import application.model.GameModelListener;
import javafx.geometry.Insets;
import javafx.scene.input.DataFormat;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;

public class WasteView extends HBox implements GameModelListener {
	private static final int PADDING = 1;
	private WasteViewListener listener;
	private boolean dragging = false;

	public WasteView() {
		setPadding(new Insets(PADDING));

		ImageView imageView = new ImageView(CardImages.getBack());
		imageView.setVisible(false);
		imageView.setOnMouseClicked(this::handleWastePileClick);

		imageView.setOnDragDetected(event -> {
			Card topCard = GameModel.getInstance().peekWaste();
			if (topCard != null) {
				dragging = true;
				Dragboard db = imageView.startDragAndDrop(TransferMode.MOVE);
				db.setDragView(imageView.snapshot(null, null));
				db.setContent(Collections.singletonMap(DataFormat.PLAIN_TEXT, topCard.toString()));
				event.consume();
			}
		});

		imageView.setOnDragDone(event -> dragging = false);

		getChildren().add(imageView);
		GameModel.getInstance().addListener(this);
	}

	@Override
	public void gameStateChanged() {
		ImageView imageView = (ImageView) getChildren().get(0);
		imageView.setVisible(true);

		Card topCard = GameModel.getInstance().peekWaste();
		if (topCard != null) {
			imageView.setImage(CardImages.getImage(topCard));
		}
	}

	private void handleWastePileClick(MouseEvent event) {
		if (!dragging && event.getButton() == MouseButton.PRIMARY && event.getClickCount() == 2) {
			Card clickedCard = GameModel.getInstance().peekWaste();
			if (clickedCard != null) {
				System.out.println("Clicked Card Suit: " + clickedCard.getSuit());
				boolean moved = GameModel.getInstance().doubleClickWastePile(clickedCard);
				if (moved && listener != null) {
					Image cardImage = CardImages.getImage(clickedCard);
					System.out.println("Card Image: " + cardImage.getUrl());
					listener.onCardMovedToFoundation(cardImage, clickedCard);
				}
			}
		}
	}

	public interface WasteViewListener {
		void onCardMovedToFoundation(Image cardImage, Card card);
	}

	public void setWasteViewListener(WasteViewListener listener) {
		this.listener = listener;
	}

	public void addCard(Card drawnCard) {
		// TODO Auto-generated method stub
		
	}
}
