
package application.card;

import javafx.scene.image.Image;

public class Card {

    private static Card[][] cards = new Card[Suit.values().length][Rank.values().length];
    private Rank rank;
    private Suit suit;
    private boolean faceUp; 

    public Card(Rank rank, Suit suit) {
        this.rank = rank;
        this.suit = suit;
        this.faceUp = false; 
    }

    public Rank getRank() {
        return rank;
    }

    public Suit getSuit() {
        return suit;
    }

    public boolean isFaceUp() {
        return faceUp;
    }

    public void setFaceUp(boolean faceUp) {
        this.faceUp = faceUp;
    }

    public static Card getCard(Rank rank, Suit suit) {
        if (cards[suit.ordinal()][rank.ordinal()] == null) {
       
            cards[suit.ordinal()][rank.ordinal()] = new Card(rank, suit);
        }
        return cards[suit.ordinal()][rank.ordinal()];
    }

    

    @Override
    public String toString() {
        return rank + " of " + suit;
    }

	
}

	
	
	

