package application.card;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class Deck {

    private Stack<Card> cards = new Stack<>();
    private Stack<Card> drawnCards = new Stack<>();
    private List<Card> originalOrder = new ArrayList<>();
    private boolean deckEmptyFlag = false;

    public Deck() {
        reset();
    }
    
    public List<Card> dealTableauCards() {
        List<Card> tableauCards = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            tableauCards.add(draw()); // Deal a card face down
            tableauCards.get(i).setFaceUp(false);
        }
        tableauCards.get(6).setFaceUp(true); // Turn the last card face up
        return tableauCards;
    }

    public void reset() {
        cards.clear();
        drawnCards.clear();
        originalOrder.clear();
        deckEmptyFlag = false;

        for (Suit suit : Suit.values()) {
            for (Rank rank : Rank.values()) {
                Card card = Card.getCard(rank, suit);
                originalOrder.add(card);
            }
        }
        shuffleDeck(); // Shuffle the original order to create the deck
        cards.addAll(originalOrder); // Fill the deck with shuffled cards
    }

    public boolean isEmpty() {
        return this.cards.isEmpty() && deckEmptyFlag;
    }

    public Card draw() {
        if (isEmpty()) {
            refillDeck();
        }

        if (cards.isEmpty()) {
            deckEmptyFlag = true;
            return draw(); // Draw the first card from the refilled deck
        }

        Card drawnCard = cards.pop();
        drawnCards.push(drawnCard);

        return drawnCard;
    }

    private void refillDeck() {
        // Refill the deck with cards in original order
        cards.addAll(originalOrder);
        deckEmptyFlag = false;
    }

    private void shuffleDeck() {
        Collections.shuffle(originalOrder); // Shuffle the original order
    }
}
