package application.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

import javafx.scene.image.Image;
import application.Foundation;
import application.card.Card;
import application.card.Deck;
import application.card.Rank;
import application.card.Suit;
import application.move.DeckMove;
import application.move.Move;

public class GameModel {
    private static final GameModel INSTANCE = new GameModel();

    private Deck deck = new Deck();
    private Stack<Card> waste;
    private List<GameModelListener> listenerList = new ArrayList<>();
    private int score = 0;
    public Foundation[] foundations;
    private List<Card>[] tableau;

    private GameModel() {
        reset();
        initializeFoundations();
        initializeTableau();
    }

    public static GameModel getInstance() {
        return INSTANCE;
    }

    public void addListener(GameModelListener listener) {
        listenerList.add(listener);
    }

    public void notifyListener() {
        for (GameModelListener listener : listenerList) {
            listener.gameStateChanged();
        }
    }

    public Move getDeckMove() {
        return new DeckMove(getInstance());
    }

    public void reset() {
        deck.reset();
        waste = new Stack<>();
        score = 0;
        listenerList.clear();
        notifyListener();
    }

    public boolean discard() {
        if (!deck.isEmpty()) {
            waste.add(deck.draw());
            notifyListener();
            return true;
        }
        return false;
    }

    public Card peekWaste() {
        if (waste.isEmpty()) {
            return null;
        }
        return waste.peek();
    }

    private void initializeFoundations() {
        foundations = new Foundation[4];
        foundations[0] = new Foundation(Suit.CLUBS);
        foundations[1] = new Foundation(Suit.DIAMONDS);
        foundations[2] = new Foundation(Suit.SPADES);
        foundations[3] = new Foundation(Suit.HEARTS);
    }

    private void initializeTableau() {
        tableau = new List[7];
        for (int i = 0; i < tableau.length; i++) {
            tableau[i] = new ArrayList<>();
        }
        dealTableauCards();
    }

    public List<Card>[] getTableau() {
        return tableau;
    }

    public void dealTableauCards() {
        for (int i = 0; i < tableau.length; i++) {
            for (int j = 0; j <= i; j++) {
                Card card = deck.draw();
                if (j == i) {
                    card.setFaceUp(true);
                }
                tableau[i].add(card);
            }
        }
        notifyListener();
    }

    public boolean doubleClickWastePile(Card clickedCard) {
        if (clickedCard != null && foundations != null) {
            System.out.println("Attempting to move card: " + clickedCard);
            for (Foundation foundation : foundations) {
                if (foundation.canAccept(clickedCard) && !foundation.containsCard(clickedCard)) {
                    System.out.println("Foundation can accept card and doesn't already contain it. Adding card...");
                    boolean moved = foundation.addCard(clickedCard);
                    if (moved) {
                        System.out.println("Card added to foundation successfully.");
                        waste.pop();
                        updateScore(10);
                        notifyListener();
                        return true;
                    } else {
                        System.out.println("Failed to add card to foundation.");
                    }
                }
            }
            System.out.println("No suitable foundation found for the card or foundation already contains the card.");
        } else {
            System.out.println("Clicked card is null or foundations are not initialized.");
        }
        return false;
    }

    public void updateScore(int points) {
        score += points;
    }

    public int getScore() {
        return score;
    }

    public Card dealCardFromTalon() {
        return null;
    }

    public Card drawCardFromDeck() {
        return null;
    }
}
