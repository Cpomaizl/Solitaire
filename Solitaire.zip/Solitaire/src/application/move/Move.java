package application.move;

import java.util.List;

import application.card.Card;

public interface Move {
	
	void move();

	List<Card> dealTableauCards();
	
}
